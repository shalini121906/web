import logo from "../img/logo.jpg"
import Input from "./Input";

function Podio(){
    const pageStyle = {
        backgroundImage: `url(${logo})`,
        
        backgroundPosition: 'center',
         // This ensures the background covers the entire viewport height
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        color: 'black', // Text color on top of the background
        fontSize: '24px', // Adjust the font size as needed
        padding:"100px"
      };
      const contentStyle = {
        background: 'rgba(0, 0, 0, 0.2)', // Semi-transparent background for the content
        padding: '20px',
      };
    
      return (
        <>
        <div style={pageStyle}>
          <div style={contentStyle}>
            <h1>Get your team working in sync</h1>
            <p>Build powerful low-code business solutions to customize work and communication</p>
          </div>
           &nbsp;<div>
           <Input color="success"/>
           </div>
        </div>
        
        </>
      );
}
export default Podio;