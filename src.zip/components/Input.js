import React, { useState } from 'react';

function Input(props) {
  const [inputValue, setInputValue] = useState('');

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleSubmit = () => {
    // Here, you can handle what happens when the "Enter" button is clicked.
    // For simplicity, we'll just display an alert with the input value.
    alert(`You entered: ${inputValue}`);
  };

  return (
    <div>
      
      <div>
        <input
          type="text"
          placeholder="Enter email"
          value={inputValue}
          onChange={handleInputChange}
        />
        <button onClick={handleSubmit} variant={props.color}>Enter</button>
      </div>
    </div>
  );
}

export default Input;
