import React from 'react';
import { Link } from 'react-router-dom';
import { Nav, NavDropdown } from 'react-bootstrap';

function Display() {
    
  return (
    <nav className="nav">
      <Link className="podio" to="/">Podio</Link>
      <ul className="ul">
        <li>
          <Link className="link" to="/features">Features</Link>
        </li>
        <li>
          <Link className="link" to="/pricing">Pricing</Link>
        </li>
        <li>
          <Link className="link" to="/usecases">Usecases</Link>
        </li>
        <li>
          <Link className="link" to="/demo">Request a demo</Link>
        </li>
        <NavDropdown title={<span className="custom-dropdown-title">More</span>} id="more-dropdown"  >
          <ul >
            <li>
            <Link className="dropdown" to="/content">Content</Link>

            </li>
            <li>
            <Link className="dropdown" to="/support">Support</Link>

            </li>
            <li>
            <Link className="dropdown" to="/jobs">jobs</Link>

            </li>
          </ul>
          
        </NavDropdown>
      </ul>
      <ul className="ul">
        <li>
          <Link className="link" to="/login">Login</Link>
        </li>
        <li>
          <Link className="link" to="/signup">Signup</Link>
        </li>
      </ul>
    </nav>
  );
}

export default Display;
