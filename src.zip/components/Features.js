
function Features(){
    return(
        <>
        <h1>Features</h1>
       
        </>
    );
}
export default Features;