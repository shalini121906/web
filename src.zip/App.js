import logo from './logo.svg';
import './App.css';
import Display from './components/Display'; 
import Podio from './components/Podio';
import Demo from './components/Demo';
import Login from './components/Login';
import Signup from './components/Signup';
import Use from './components/Use';

import Features from './components/Features';
import Pricing from './components/Pricing';
import { Route,Routes } from 'react-router-dom';
function App() {
  return (
    <>
    <Display/>
    <div>
      <Routes>
        <Route path="/" element={<Podio/>}/>
        <Route path="/pricing" element={<Pricing/>}/>
        <Route path="/features" element={<Features/>}/>
        <Route path="/usecases" element={<Use/>}/>
        <Route path="/demo" element={<Demo/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/signup" element={<Signup/>}/>
      </Routes>
    </div>
    </>
    
  );
}

export default App;
