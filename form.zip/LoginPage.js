import React, { Component } from 'react';
import LoginForm from './LoginForm';

class LoginPage extends Component {
  handleSubmit = (user) => {
    this.props.onLogin(user);
  };

  render() {
    return (
      <div>
        <h2>Login</h2>
        <LoginForm onSubmit={this.handleSubmit} />
      </div>
    );
  }
}

export default LoginPage;
