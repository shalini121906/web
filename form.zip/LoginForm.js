import React, { Component } from 'react';
import './login.css';

class LoginForm extends Component {
  constructor() {
    super();
    this.state = {
      username: '',
      email: '',
      password: '',
      error: '',
    };
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    const { username, email, password } = this.state;

    // Password validation (1 lowercase, 1 uppercase, 1 number)
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(password)) {
      this.setState({ error: 'Password must contain 1 lowercase, 1 uppercase, and 1 number.' });
      return;
    }

    this.props.onSubmit({ username, email, password });
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={this.state.username}
          onChange={this.handleInputChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={this.state.email}
          onChange={this.handleInputChange}
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={this.state.password}
          onChange={this.handleInputChange}
          required
        />
        <button type="submit">Log In</button>
        {this.state.error && <p className="error">{this.state.error}</p>}
      </form>
    );
  }
}

export default LoginForm;
