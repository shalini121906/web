import React from 'react';

const WelcomePage = ({ user, onLogout }) => {
  return (
    <div>
      <h2>Welcome, {user.username}!</h2>
      <button onClick={onLogout}>Log Out</button>
    </div>
  );
};

export default WelcomePage;
