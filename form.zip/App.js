import React, { Component } from 'react';
import LoginPage from './LoginPage';
import WelcomePage from './WelcomePage';

class App extends Component {
  constructor() {
    super();
    this.state = {
      loggedInUser: null,
      users: [
        { username: 'john123', email: 'john@example.com', password: 'Password1' },
        { username: 'jane456', email: 'jane@example.com', password: 'Password2' },
      ],
    };
  }

  handleLogin = (user) => {
    // Check if the user's credentials match any entry in the local list.
    const matchedUser = this.state.users.find(
      (u) => u.email === user.email && u.password === user.password
    );

    if (matchedUser) {
      this.setState({ loggedInUser: matchedUser });
    }
  };

  handleLogout = () => {
    this.setState({ loggedInUser: null });
  };

  render() {
    return (
      <div className="App">
        {this.state.loggedInUser ? (
          <WelcomePage user={this.state.loggedInUser} onLogout={this.handleLogout} />
        ) : (
          <LoginPage onLogin={this.handleLogin} />
        )}
      </div>
    );
  }
}

export default App;
